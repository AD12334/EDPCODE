package com.mycompany._23358173_server;

import javafx.application.Platform;
import javafx.stage.Stage;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;


public class Server {
    static String[] modules = new String[5];
    static LinkedHashMap<String, Lecture[]> schedule = new LinkedHashMap<>();
    static HashMap<Integer, String> days = new HashMap<>();
    static HashMap<Integer, String> reverse_intervals = new HashMap<>();
    static LinkedList<Thread> threads = new LinkedList<>();
    static App app;
    static Thread t;
    private static final ConcurrentHashMap<Socket, PrintWriter> connectedClients = new ConcurrentHashMap<>();


    public static void main(String[] args) throws IOException {
        System.out.println(new File(".").getAbsolutePath());

        try (PrintWriter writer = new PrintWriter("src\\main\\java\\com\\mycompany\\_23358173_server\\Connection_info.csv")) {
            writer.print(""); //clearing the csv

        } catch (IOException e) {
            System.err.println("Error clearing CSV file: " + e.getMessage());
        }
        try (ServerSocket serverSocket = new ServerSocket(1054);
             Scanner scanner = new Scanner(System.in)) {
            System.out.println("Server is running and waiting for clients...");
            Server server = new Server();

            //populating hashmaps for converting client message into workable data
            days.put(0, "Monday");
            days.put(1, "Tuesday");
            days.put(2, "Wednesday");
            days.put(3, "Thursday");
            days.put(4, "Friday");
            reverse_intervals.put(0, "9:00-10:00");
            reverse_intervals.put(1, "10:00-11:00");
            reverse_intervals.put(2, "11:00-12:00");
            reverse_intervals.put(3, "12:00-13:00");
            reverse_intervals.put(4, "13:00-14:00");
            reverse_intervals.put(5, "14:00-15:00");
            reverse_intervals.put(6, "15:00-16:00");
            reverse_intervals.put(7, "16:00-17:00");
            reverse_intervals.put(8, "17:00-18:00");
            server.createMap(schedule);
            server.csvReader();

            t = new Thread(() -> App.launch(App.class));
            t.start();// server gui


            //main loop for communicating with clients
            while (true) {
                Socket socket = serverSocket.accept();

                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                {
                    connectedClients.put(socket, new PrintWriter(socket.getOutputStream(), true));
                    System.out.println("Client connected!");
                    threads.add(new Thread(new Server_thread(socket, server)));
                    threads.get(threads.size() - 1).start();
                    //we should probably have an array of all our clients or something
                    server.connection_info(socket.getLocalPort() + ",", socket.getLocalAddress() + "");
                    //server.handleMessages(socket, in, scanner);
                }
            }
        }
    }


    //takes in messages from client, converts them to workable requests
    public void handleMessages(Socket socket, BufferedReader in, PrintWriter out) throws IOException {
        String message;


        try {
            //Read messages until client disconnects
            while ((message = in.readLine()) != null) {
                if (message.length() > 0) {
                    String request = message.substring(0, 1);
                    String content = message.substring(1);
                    String[] info = content.split("/");
                    String day;
                    String time;
                    String room;
                    String code;

                    switch (request) {
                        //Add new lecture
                        case ("A"):
                            day = info[0].toLowerCase();
                            time = info[1];
                            room = info[2];
                            code = info[3].toUpperCase();
                             out.println(attemptSchedule(Integer.parseInt(time), day, room, code));



                            break;
                        //Remove lecture
                        case ("R"):
                            day = info[0];
                            time = info[1];
                             out.println(removelecture(day, Integer.parseInt(time)));

                            break;
                        //View Schedule
                        case ("V"):
                            viewSchedule(socket);
                            break;
                        //Options Button
                        case ("O"):
                            try {
                                throw new IncorrectActionException();
                            } catch (IncorrectActionException e) {
                                out.println(e.getMessage());
                            }
                            //Early lectures request
                        case ("E"):
                            System.out.println("E Received");
                            earlyLectures();
                            out.println("Success");
                            System.out.println(schedule);

                            break;
                        //Disconnect Client
                        case ("S"):
                            out.println("TERMINATE");
                            try {
                                socket.close();
                                System.out.println("Client disconnected");

                            } catch (IOException e) {
                                System.err.println("Error closing socket: " + e.getMessage());
                            }
                            break;
                        default:
                            System.out.println(message);
                    }
                }
            }
        } catch (SocketException e) {


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    synchronized String attemptSchedule(int time, String day, String room, String module) {
        System.out.println(time + " " + day + " " + room + " " + module);
        if (!checkSchedule(time, day, room)) {
            return "There is already a lecture scheduled for this time and date";
        } else if (!checkModules(module)) {
            return "Can only create five modules";
        } else {
            Lecture lecture = new Lecture(room, module);
            schedule.get(day)[time] = lecture;
            csvWriter(time, day, room, module);
            Platform.runLater(() -> App.instance.refreshgui());//Accessing the one instance of our sever gui and updating it
            return "Lecture has been scheduled for " + days.get(Integer.parseInt(day)) + " " + reverse_intervals.get(time);
        }
    }

    synchronized String  removelecture(String day, int time) {
        if (schedule.get(day)[time] != null) {
            schedule.get(day)[time] = null;
            csvWriter(time, day, "", "");
            Platform.runLater(() -> App.instance.refreshgui());//Server GUI
            return "Removed lecture at " + days.get(Integer.parseInt(day)) + " " + reverse_intervals.get(time);
        }

        return "No lecture scheduled for this time"; //Throw incorrect action exception here maybe??
    }

    static void viewSchedule(Socket socket) throws IOException {
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        //FOR LOOP TO FORMAT THE OUTPUT
        for (int i = 0; i < schedule.size(); i++) {
            String index = String.valueOf(i);
            String message = "";
            for (int j = 0; j < schedule.get(index).length; j++) {
                if (schedule.get(index)[j] != null) {
                    message += schedule.get(index)[j] + "/";
                } else {
                    message += " /";
                }
            }
            System.out.println(message);
            out.println(message);

        }
    }

    //early lecture call
    synchronized static void earlyLectures() {
        //creating early threads to move all lectures to earlier time slots
        System.out.println("early lectures called");
      Early early = new Early(schedule);
      schedule = early.compute();
      System.out.println("early lectures finished!");
        Platform.runLater(() -> App.instance.refreshgui());
        csvSchedule(schedule);


    }

    private boolean checkSchedule(int time, String day, String room) {
        //check if the time of the lecture doesn't clash with another lecture
        System.out.println(time + " " + day + " " + room);

        if (schedule.get(day)[time] != null) {
            return false;
        } else if (schedule.get(day)[time] != null && schedule.get(day)[time].getRoom().equals(room)) {
            return false; // ROOM CHECK
        }
        return true;

    }
        private boolean checkModules (String module){
            for (int i = 0; i < 5; i++) {
                if (module.equals(modules[i])) {
                    return true;
                } else if (modules[i] == null) {
                    modules[i] = module;
                    return true;
                }
            }
            return false;
        }


        //creating hashmap for lectures during the week
        private void createMap (Map < String, Lecture[]>map){
            map.put("0", new Lecture[9]);
            map.put("1", new Lecture[9]);
            map.put("2", new Lecture[9]);
            map.put("3", new Lecture[9]);
            map.put("4", new Lecture[9]);
        }

        // writes changes to csv
        private void csvWriter ( int time, String day, String room, String module){
            ArrayList<String[]> data = new ArrayList<>();

            //reading csv into memory
            try (BufferedReader csvReader = new BufferedReader(new FileReader("src\\main\\java\\com\\mycompany\\_23358173_server\\schedule.csv"))) {
                String line;

                while ((line = csvReader.readLine()) != null)
                    data.add(line.split(",", -1));

            } catch (Exception e) {
                System.out.println("Error writing data to memory");
            }

            Lecture lecture = new Lecture(room, module);

            // changing data
            data.get(time)[Integer.parseInt(day)] = lecture.toString();

            //writing data back to csv
            try (BufferedWriter csvWriter = new BufferedWriter(new FileWriter("src\\main\\java\\com\\mycompany\\_23358173_server\\schedule.csv"))) {
                for (String[] lineData : data) {
                    csvWriter.write(String.join(",", lineData));
                    csvWriter.newLine();
                }
            } catch (Exception e) {
                System.err.println("Could not write data to database");
            }
        }

        private static void csvSchedule(LinkedHashMap<String, Lecture[]> schedule){
            System.out.println(schedule);
            try (BufferedWriter csvWriter = new BufferedWriter(new FileWriter("src\\main\\java\\com\\mycompany\\_23358173_server\\schedule.csv"))) {
                //Writes the csv to data after calling early schedule
                for(int i = 0; i < schedule.get("0").length; i++){
                    for(int j = 0; j < schedule.size(); j++){
                        if(schedule.get(String.valueOf(j))[i] != null && j != schedule.get(String.valueOf(j)).length){
                            csvWriter.write(String.valueOf(schedule.get(String.valueOf(j))[i]) + ",");
                        }else if(schedule.get(String.valueOf(j))[i] == null && i != schedule.get(String.valueOf(j)).length ) {
                            csvWriter.write(",");
                        }else if (schedule.get(String.valueOf(j))[i] != null && i == schedule.get(String.valueOf(j)).length){
                            csvWriter.write(String.valueOf(schedule.get(String.valueOf(j))[i]));
                        }
                    }

                    csvWriter.newLine();
                }
            } catch (Exception e) {
                System.err.println("Could not write data to database");
            }

        }

        //prints name and state of server threads
        private void connection_info (String port, String Ip) throws IOException {
            try (BufferedWriter csvwriter = new BufferedWriter(new FileWriter("src\\main\\java\\com\\mycompany\\_23358173_server\\Connection_info.csv"))) {
                for (int i = 0; i < threads.size(); i++) {
                    csvwriter.write(threads.get(i).getName() + "," + threads.get(i).getState() + "\n");
                }
            }
        }

        //reads in the csv into the hashmap
        private void csvReader () {
            String[] data;

            try (BufferedReader csvReader = new BufferedReader(new FileReader("src\\main\\java\\com\\mycompany\\_23358173_server\\schedule.csv"))) {
                String line;
                int index = 0;

                while ((line = csvReader.readLine()) != null) {
                    data = line.split(",", -1);

                    for (int i = 0; i < 5; i++) {
                        String[] details = data[i].split("-");
                        if (details.length == 2) {
                            Lecture lecture = new Lecture(details[0], details[1]);
                            if (schedule.get(String.valueOf(i))[index] == null) {
                                schedule.get(String.valueOf(i))[index] = lecture;
                            }
                        }
                    }
                    index++;
                }
            } catch (FileNotFoundException e) {
                System.err.println("file not found");
                e.printStackTrace();
            } catch (IOException e) {
                System.out.println("reader error");
            }
        }
    }

