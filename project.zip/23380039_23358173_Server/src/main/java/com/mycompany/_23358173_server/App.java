package com.mycompany._23358173_server;



import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.time.DayOfWeek;
import java.net.InetAddress;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class App extends Application {
    GridPane grid;
    public static App instance;
    Stage stage;
    String[] titles = {"MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY"};
    String[] times = {"9:00-10:00", "10:00-11:00", "11:00-12:00", "12:00-13:00", "13:00-14:00", "14:00-15:00", "15:00-16:00", "16:00-17:00", "17:00-18:00"};


    String[] colorarr = {
            "-fx-text-fill: green",
            "-fx-text-fill: blue",
            "-fx-text-fill: red",
            "-fx-text-fill: orange",
            "-fx-text-fill: purple"
    };
    HashMap<String, String> colors = new HashMap<>();
    VBox[] arr = new VBox[5];
    VBox vbox;





    @Override
    public void start(Stage stage) throws Exception {
        instance = this; // A reference to our one and only gui for the server


            this.stage = stage;

            LinkedHashMap<String, Lecture[]> schedule = Server.schedule;
            String[][] schedule2d = new String[schedule.size()][];

            for (int i = 0; i < schedule.size(); i++) {
                //Our initial array was an arrray of strings each containing the lecture info for a given day
                //In order to interpret this info we are going to split each array using the delimiter /
                //We can put these split contents into another array which we store in another array for each day (array of days which is an array of lecture info)
                // Split each string in the input array and store it in the corresponding row of the 2D array
                //WE had an array of just days
                //Now we have a 2d array for days and times

                schedule2d[i] = new String[schedule.get(String.valueOf(i)).length];
            }


            for (int i = 0; i < schedule.size(); i++) {
                for (int j = 0; j < schedule.get(String.valueOf(i)).length; j++) {
                    if (schedule.get(String.valueOf(i))[j] == null) {
                        schedule2d[i][j] = " ";
                    } else {
                        schedule2d[i][j] = (schedule.get(String.valueOf(i))[j]).toString();
                    }
                }
            }


            //WE NOW HAVE A HASHMAP THAT MAPS A MODULE TO A COLOR
            //SCHEDULE IS AN ARRAY WHERE THE KEY IS THE DAY (e.g. schedule[0] - monday stuff)
            //THE CONTENTS IN EACH KEY IS THE LECTURES SCHEDULED FOR THAT DAY
            //EACH LECTURE IS ADDED TO THE KEY IN ACCORDANCE TO ITS ORDER IN THE DAY
            //e.g. a tuesday with only one lecture will be at index 2 and will contain null values apart from one area

            stage.setWidth(900);
            stage.setHeight(500);
            stage.setTitle("Server GUI");
            grid = new GridPane();
            grid.minWidthProperty().bind(stage.widthProperty());
            grid.minHeightProperty().bind(stage.heightProperty());
            grid.maxHeightProperty().bind(stage.heightProperty());

            // Set row constraints to make schedule fill remaining space
            RowConstraints buttonRow1 = new RowConstraints();
            buttonRow1.setPrefHeight(40);
            buttonRow1.setVgrow(Priority.NEVER);

            RowConstraints buttonRow2 = new RowConstraints();
            buttonRow2.setPrefHeight(40);
            buttonRow2.setVgrow(Priority.NEVER);

            RowConstraints scheduleRow = new RowConstraints();
            scheduleRow.setVgrow(Priority.ALWAYS);

            grid.getRowConstraints().addAll(buttonRow1, buttonRow2, scheduleRow);

            //**************************EXIT BUTTON****************************
            Button exit = new Button("EXIT");
            exit.setOnAction(e -> System.exit(0));
            exit.setAlignment(Pos.CENTER);
            exit.setFont(Font.font("Comic Sans", FontWeight.BOLD, 10));
            exit.minWidthProperty().bind(grid.widthProperty());
            exit.prefWidthProperty().bind(grid.widthProperty());
            GridPane.setColumnSpan(exit, 6); // Span all columns
            exit.prefHeightProperty().bind(stage.heightProperty().divide(15));
            exit.minHeightProperty().bind(stage.heightProperty().divide(15));
            grid.add(exit, 0, 0); // Column 0, Row 0

            //**************************EARLY BUTTON****************************
            Button early = new Button("EARLY SCHEDULE");
            early.setOnAction(e ->  Server.earlyLectures());

            early.setFont(Font.font("Comic Sans", FontWeight.BOLD, 10));
            early.setAlignment(Pos.CENTER);
            early.minWidthProperty().bind(grid.widthProperty());
            early.prefWidthProperty().bind(grid.widthProperty());
            GridPane.setColumnSpan(early, 6); // Span all columns
            early.prefHeightProperty().bind(stage.heightProperty().divide(15));
            early.minHeightProperty().bind(stage.heightProperty().divide(15));
            grid.add(early, 0, 1); // Column 0, Row 1 (below EXIT button)


            //**************************TEXTFIELDS****************************

            for (int i = 0; i < 5; i++) {
                VBox vbox = new VBox();
                vbox.minWidthProperty().bind(stage.widthProperty().divide(6));
                vbox.maxWidthProperty().bind(stage.widthProperty().divide(6));
                vbox.setStyle("-fx-border-color: black; -fx-border-width: 2; -fx-border-style: solid;");
                vbox.setMaxHeight(Double.MAX_VALUE);
                VBox.setVgrow(vbox, Priority.ALWAYS);

                arr[i] = vbox;
            }
            vbox = new VBox();
            vbox.minWidthProperty().bind(stage.widthProperty().divide(6));
            vbox.maxWidthProperty().bind(stage.widthProperty().divide(6));
            vbox.setStyle("-fx-border-color: black; -fx-border-width: 2; -fx-border-style: solid;");
            vbox.setMaxHeight(Double.MAX_VALUE);
            VBox.setVgrow(vbox, Priority.ALWAYS);

//DAYS
            for (int i = 0; i < titles.length; i++) {
                TextField t = new TextField();
                t.setEditable(false);
                t.setText(titles[i]);
                t.setAlignment(Pos.CENTER);
                t.setFont(Font.font("Comic Sans", FontWeight.BOLD, 15));
                t.setStyle("-fx-background-color: transparent; -fx-border-color: BLACK");
                arr[i].getChildren().add(t);
            }

            // Time
            TextField Time = new TextField();
            Time.setText("TIME");
            Time.setAlignment(Pos.CENTER);
            Time.setFont(Font.font("Comic Sans", FontWeight.BOLD, 15));
            Time.setStyle("-fx-background-color: transparent; -fx-border-color: BLACK");
            vbox.getChildren().add(Time);

            // Lecture Times
            for (int i = 0; i < times.length; i++) {
                TextField t = new TextField();
                t.setAlignment(Pos.CENTER);
                t.setFont(Font.font("Comic Sans", FontWeight.BOLD, 15));
                t.setEditable(false);
                t.setMaxHeight(Double.MAX_VALUE);
                VBox.setVgrow(t, Priority.ALWAYS);
                t.setStyle("-fx-border-color: BLACK");
                t.setText(times[i]);
                vbox.getChildren().add(t);
            }

            for (int i = 0; i < schedule2d.length; i++) {
                for (int j = 0; j < times.length; j++) {
                    if (schedule2d[i][j].equals(" ")) {
                        continue;
                    } else {
                        String[] temp = schedule2d[i][j].split("-"); //IF THE SLOT HAS NO LECTURE THEN NO COLOR NEEDED
                        String module = temp[1];
                        if (!colors.containsKey(module)) {//IF THE MODULE ISNT ALREADY IN OUR HASHMAP
                            colors.put(module, colorarr[colors.size()]);
                            //PUT THE MODULE CODE AS KEY
                            //PUT THE COLOR AS THE VALUE
                            //WE CAN USE THE SIZE OF THE COLOR HASHMAP AS AN INDEX INTO OUR COLORS ARRAY
                        }
                    }
                }
            }
            for (int i = 0; i < 5; i++) { //5 days
                for (int j = 0; j < 9; j++) {//9 possible lecture slots
                    TextField t = new TextField();
                    t.setAlignment(Pos.CENTER);
                    t.setEditable(false);
                    t.setMaxHeight(Double.MAX_VALUE);
                    VBox.setVgrow(t, Priority.ALWAYS);
                    t.setFont(Font.font("Comic Sans", FontWeight.BOLD, 15));

                    if (schedule2d[i][j].equals(" ")) {
                        t.setStyle("-fx-border-color: BLACK");
                    } else {
                        String[] temp = schedule2d[i][j].split("-");
                        String module = temp[1];
                        t.setStyle("-fx-border-color: BLACK; " + colors.get(module));
                    }

                    t.setText(schedule2d[i][j]); //setting the text for each day
                    arr[i].getChildren().add(t);
                }
            }
            // Adding the finished product
            grid.add(vbox, 0, 2); // Time column at column 0, row 2
            for (int i = 1; i < 6; i++) {
                grid.add(arr[i - 1], i, 2); // Day columns at columns 1-5, row 2
            }

            //**************************STAGE SETUP****************************
            ScrollPane scrollPane = new ScrollPane(grid);
            scrollPane.setFitToWidth(true); // Ensure the width fits the stage
            scrollPane.setFitToHeight(true); // Ensure the height fits the stage
            scrollPane.minWidthProperty().bind(stage.widthProperty());
            scrollPane.minHeightProperty().bind(stage.heightProperty());
            scrollPane.maxWidthProperty().bind(stage.widthProperty());
            scrollPane.maxHeightProperty().bind(stage.heightProperty());

            Scene scene = new Scene(scrollPane);
            stage.setScene(scene);
            stage.show();



        }

       public void refreshgui(){
        //We need an update schedule function that accessess all of our important components and then updates them
            //We should initialise all the vboxes as global variables and then edit their components as needed


            //we need to access the components of arr and then update the components
            Platform.runLater(() -> {
                LinkedHashMap<String, Lecture[]> schedule = Server.schedule;
                String[][] schedule2d = new String[schedule.size()][];

                for(int i = 0; i < arr.length; i++){
                    arr[i].getChildren().clear();
                }

                for (int i = 0; i < schedule.size(); i++) {
                    //Our initial array was an arrray of strings each containing the lecture info for a given day
                    //In order to interpret this info we are going to split each array using the delimiter /
                    //We can put these split contents into another array which we store in another array for each day (array of days which is an array of lecture info)
                    // Split each string in the input array and store it in the corresponding row of the 2D array
                    //WE had an array of just days
                    //Now we have a 2d array for days and times

                    schedule2d[i] = new String[schedule.get(String.valueOf(i)).length];
                }


                for (int i = 0; i < schedule.size(); i++) {
                    for (int j = 0; j < schedule.get(String.valueOf(i)).length; j++) {
                        if (schedule.get(String.valueOf(i))[j] == null) {
                            schedule2d[i][j] = " ";
                        } else {
                            schedule2d[i][j] = (schedule.get(String.valueOf(i))[j]).toString();
                        }
                    }
                }
                for (int i = 0; i < schedule2d.length; i++) {
                    for (int j = 0; j < times.length; j++) {
                        if (schedule2d[i][j].equals(" ")) {
                            continue;
                        } else {
                            String[] temp = schedule2d[i][j].split("-"); //IF THE SLOT HAS NO LECTURE THEN NO COLOR NEEDED
                            String module = temp[1];
                            if (!colors.containsKey(module)) {//IF THE MODULE ISNT ALREADY IN OUR HASHMAP
                                colors.put(module, colorarr[colors.size()]);
                                //PUT THE MODULE CODE AS KEY
                                //PUT THE COLOR AS THE VALUE
                                //WE CAN USE THE SIZE OF THE COLOR HASHMAP AS AN INDEX INTO OUR COLORS ARRAY
                            }
                        }
                    }
                }
                //DAYS
                for (int i = 0; i < titles.length; i++) {
                    TextField t = new TextField();
                    t.setEditable(false);
                    t.setText(titles[i]);
                    t.setAlignment(Pos.CENTER);
                    t.setFont(Font.font("Comic Sans", FontWeight.BOLD, 15));
                    t.setStyle("-fx-background-color: transparent; -fx-border-color: BLACK");
                    arr[i].getChildren().add(t);
                }


                for (int i = 0; i < 5; i++) { //5 days
                    for (int j = 0; j < 9; j++) {//9 possible lecture slots
                        TextField t = new TextField();
                        t.setAlignment(Pos.CENTER);
                        t.setEditable(false);
                        t.setMaxHeight(Double.MAX_VALUE);
                        VBox.setVgrow(t, Priority.ALWAYS);
                        t.setFont(Font.font("Comic Sans", FontWeight.BOLD, 15));

                        if (schedule2d[i][j].equals(" ")) {
                            t.setStyle("-fx-border-color: BLACK");
                        } else {
                            String[] temp = schedule2d[i][j].split("-");
                            String module = temp[1];
                            t.setStyle("-fx-border-color: BLACK; " + colors.get(module));
                        }

                        t.setText(schedule2d[i][j]); //setting the text for each day
                        arr[i].getChildren().add(t);
                    }
                }







            });

        }
    }





