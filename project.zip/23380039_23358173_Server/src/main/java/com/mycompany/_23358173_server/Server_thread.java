package com.mycompany._23358173_server;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;

public class Server_thread implements Runnable {
    private final Socket clientSocket;
    private final Server server;

    public Server_thread(Socket clientSocket, Server server) {
        this.clientSocket = clientSocket;
        this.server = server;
    }

    @Override
    public void run() {
        PrintWriter out = null;
        BufferedReader in = null;

        try {
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            //public void handleMessages(Socket socket, BufferedReader in, Scanner scanner)

            server.handleMessages(clientSocket, in, out);


        } catch (IOException e) {
            System.out.println("Server Error");
        }


    }
}