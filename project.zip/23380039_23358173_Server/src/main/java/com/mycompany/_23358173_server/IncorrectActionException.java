package com.mycompany._23358173_server;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author downe
 */
public class IncorrectActionException extends Exception{
    
    
    public IncorrectActionException(){
        super("Incorrect Action has been committed :( \n");
    }
}