package com.mycompany._23358173_server;


import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.RecursiveTask;

/**
 * Early
 */
public class Early extends RecursiveTask<LinkedHashMap<String,Lecture[]>> {
    //Designed to run in parallel using the Fork/join framework and return a hashmap when done
    //Returns our schedule
    LinkedHashMap<String, Lecture[]> schedule;
    //Each entry in our hashmap is a String representing the day, accompanied by all the lecture info for the day
    int index = 0;

    public Early(LinkedHashMap<String, Lecture[]> schedule) {
        this.schedule = schedule;
    }

    //moves lectures in an array to the earliest available time slots
    private Lecture[] moveLectures(Lecture[] day) {

        //Finds the earliest available time slot in the day
        //Finds the next non null lecture in the array
        //Moves the lecture to that time
        //Stops when no more lectures can be moved forward
        int freeSlot = -1;
        boolean isFinished = false;
        boolean moved = false;

        //we keep doing this until there are no more lectures to push forward
        while (!isFinished) {
            moved = false;
            //loop through the day first to find the earliest time slot available
            for(int i = 0; i < day.length; i++) {
                if(day[i] == null) {

                    freeSlot = i;
                    //System.out.println("Free slot: " + freeSlot);
                    break;
                }
            }
            if (freeSlot == -1) {
                // No free slots at all — we're done
                isFinished = true;

            }


            //Find earliest lecture and place it in earliest available time slot

            //Issue is as follows, we have no check at the moment for if freeslot comes before our our fisrst lecture
            // we lack a check to see if the current earliest lecture is before our
            // current earliest available slot and this is causing an infinite loop because
            // we are essentially just swapping a lecture with itself over and over
            for(int i = 0; i < day.length; i++) {
                if(day[i] != null) {
                    if (i > freeSlot) {
                        day[freeSlot] = day[i];
                        day[i] = null;
                        moved = true;
                        if (i == day.length - 1) {
                            isFinished = true;
                        }
                        break;
                    }
                }
            }
            if(!moved){//if there are no possibilities to move lectures to earlier times then exit the loop
                isFinished = true;
            }

        }

        return day;

    }

    @Override
    protected LinkedHashMap<String,Lecture[]> compute() {

        LinkedHashMap<String,Lecture[]> result = new LinkedHashMap<>();
        System.out.println(schedule.size());
        //if the size of the hashmap is 1, then call moveLectures with the array
        if (schedule.size() == 1) {
            Map.Entry<String, Lecture[]> first = schedule.entrySet().iterator().next();
            Lecture[] day = moveLectures(first.getValue());
            result.put(first.getKey(), day);//If there is only one day to process , just call moveLectures on that day and return the result
        } else {
            //split original hashmap in two
            LinkedHashMap<String, Lecture[]> firstHalf = new LinkedHashMap<String, Lecture[]>();
            LinkedHashMap<String, Lecture[]> secondHalf = new LinkedHashMap<String, Lecture[]>();//Split the schedule into two halfs
            int counter = 0;
            int half = schedule.size() / 2;
            //fill in the two hashmaps
            for (String key : schedule.keySet()) {
                if (counter < half) {
                    firstHalf.put(key, schedule.get(key));//Iterate over the keys in the schedule and seperate the first half into firsthalf and the second half into secondhalf
                } else {
                    secondHalf.put(key, schedule.get(key));
                }
                //increase counter to keep track of position in hashmap
                counter++;
            }

            //create two threads recursively to operate on the halved hashmap
            Early first = new Early(firstHalf);
            Early second = new Early(secondHalf);

            first.fork();//Starts processing the first half
            System.out.println("forking first thread");
            secondHalf = second.compute();//Processes the secondhalf in the current thread
            firstHalf = first.join();//Waits for the first half to finish and gets its result
            /**
             * so we fork our first half causing it to be put onto a
             * seperate thread and compute is called on it.
             * Meanwhile on the main thread we call second.
             * compute which essentially does a bit of recursion
             * and then once both are of size one we join the results
             */
            for (String key : firstHalf.keySet()) {
                result.put(key, firstHalf.get(key));//Occupying our results hashmap
            }
            for (String key : secondHalf.keySet()) {
                result.put(key, secondHalf.get(key));
            }
        }

        return result ;
    }
}
