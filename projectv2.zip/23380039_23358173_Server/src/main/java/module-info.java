module com.mycompany._23358173_server {
    requires javafx.controls;
    exports com.mycompany._23358173_server;
}
